#include <mpi.h>
#include <iostream>
#include <stdio.h>
using namespace std;
#ifdef __cplusplus
extern "C" {
  #endif
  float f1(float x, int intensity);
  float f2(float x, int intensity);
  float f3(float x, int intensity);
  float f4(float x, int intensity);
  #ifdef __cplusplus
}
#endif

int main(int argc, char * argv[]) {

  if (argc < 6) {
    std::cerr << "usage: mpirun " << argv[0] << " <functionid> <a> <b> <n> <intensity>" << std::endl;
    return -1;
  }

  MPI_Init( & argc, & argv);

  int rank, size;

  int funID = atoi(argv[1]), n = atoi(argv[4]), intensity = atoi(argv[5]);
  float a = atof(argv[2]), b = atof(argv[3]), tmp;
  tmp = (b - a) / n;

  float( * func)(float, int);
  switch (funID) {
  case 1:
    func = & f1;
    break;
  case 2:
    func = & f2;
    break;
  case 3:
    func = & f3;
    break;
  case 4:
    func = & f4;
    break;

  default:
    cerr << "Please choose among 1, 2, 3 or 4" << endl;
    return -1;

  };
  MPI_Comm_rank(MPI_COMM_WORLD, & rank);
  MPI_Comm_size(MPI_COMM_WORLD, & size);
  float tmpInt;
  int p = n / size;

  if (rank == 0) {
    double st = MPI_Wtime();
    float integral = 0.0;
    for (int i = 1; i < size; i++) {

      int st1 = (i - 1) * p, end1 = i * p;
      if (i == (size - 1))
        end1 = n;
      MPI_Send( & start1, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
      MPI_Send( & end1, 1, MPI_INT, i, 1, MPI_COMM_WORLD);

    }
    int k = 1;
    while (k != size) {
      float pInt;
      int count;
      MPI_Status status;
      MPI_Recv( & pInt, 1, MPI_FLOAT, MPI_ANY_SOURCE, 2, MPI_COMM_WORLD, & status);
      MPI_Get_count( & status, MPI_INT, & count);
      int x = -1;
      MPI_Send( & x, 1, MPI_INT, status.MPI_SOURCE, 0, MPI_COMM_WORLD);
      k++;
      integral += pInt;
    }
    double end = MPI_Wtime();
    cout << tmp * integral << endl;
    cerr << end - st << endl;
  } else {
    int st2, end2;
    while (true) {
      MPI_Recv( & st2, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      if (st2 == -1) break;
      MPI_Recv( & end2, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      tmpInt = 0.0;
      for (int i = st2; i < end2; i++) {
        float x1 = (i + 0.5) * tmp;
        tmpInt += func(a + x1, intensity);
      }
      MPI_Send( & tmpInt, 1, MPI_FLOAT, 0, 2, MPI_COMM_WORLD);

    }
  }

  MPI_Finalize();

  return 0;
}