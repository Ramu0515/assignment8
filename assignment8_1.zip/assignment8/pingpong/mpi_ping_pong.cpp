#include <mpi.h>
#include <iostream>

int main (int argc, char* argv[]) {

  if (argc < 2) {
    std::cerr<<"usage: mpirun "<<argv[0]<<" <value>"<<std::endl;
    return -1;
  }
  MPI_Init(&argc,&argv);
  
		int size,rank;
		MPI_Comm_size(MPI_COMM_WORLD, &size);
 		MPI_Comm_rank(MPI_COMM_WORLD, &rank);

		if(size!=2)
		{
			std::cerr<<"Please enter 2 processors";
			return -1;
		}
int count=0;
		
			int processor1_rev;
			int k;
	
	int z;
	int sendvariable=atoi(argv[1]);
	int recv;
	int partner_rank = (rank + 1) % 2;
for(int count=0;count<5;count++) {
    if (rank == 0) {
			if(count==0)
			{
 printf("%d sent variable  %d from %d to %d\n",
               rank, sendvariable, 0,1);

        MPI_Send(&sendvariable, 1, MPI_INT, 1, 0,
                 MPI_COMM_WORLD);
			}
				 	 
			if(count==4)
			{
			MPI_Recv(&recv, 1, MPI_INT, 1, 0,
                 MPI_COMM_WORLD, MPI_STATUS_IGNORE);
				   printf("%d received variable %d from %d\n",
               rank, recv, 1);
				 
			}
		
    } else {
	
		if(count==1)
		{
        MPI_Recv(&z, 1, MPI_INT, 0, 0,
                 MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		    printf("%d received variable %d from %d\n",   rank, z, 0);

	z+=2;			 
		}

	//	z+=2;
		if(count==3)
		{
			        MPI_Send(&z, 1, MPI_INT, 0, 0,
                 MPI_COMM_WORLD);
 printf("%d sent variable  %d from %d to %d\n",
               rank, z, 1,0);
		}
    }
}	
		// Finalize the MPI environment.
		MPI_Finalize();

	  

  



  


  return 0;
}
