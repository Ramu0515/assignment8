#include <mpi.h>
#include <math.h>
#include <iostream>
using namespace std;

#ifdef __cplusplus
extern "C" {
#endif
  double generate2DHeat(long n, long global_i, long global_j);

  int check2DHeat(long n, long global_i, long global_j, double v, long k); 
//this function return 1 on correct. 0 on incorrect. Note that it may return 1 on incorrect. But a return of 0 means it is definitely incorrect
#ifdef __cplusplus
}
#endif

double genH0(long row, long col, long n) {
  double val = (double)(col == (n/2));
  return val;
}



int main(int argc, char* argv[]) {
  if (argc < 3) {
    std::cerr<<"usage: mpirun "<<argv[0]<<" <N> <K>"<<std::endl;
    return -1;
  }

  MPI_Init(&argc,&argv);
  long n, k;
  int rank, np;
double vv=np;
  n = atol(argv[1]);
  k= atol(argv[2]);

   
   MPI_Comm_rank(MPI_COMM_WORLD,&rank);
   MPI_Comm_size(MPI_COMM_WORLD,&np);

   int p = sqrt(np);
   long div = n/p; 
   
   int rDiv = rank/p,cDiv = rank%p;

   double**  H = new double*[div];
   double**  G = new double*[div];
   for(long i=0;i<div;i++)
     {
     H[i] = new double[div];
     G[i] = new double[div];
     
   }
   
   long rowstart = (rDiv*div),colstart = (cDiv*div);
   long rowend = rowstart+div,colend = colstart+div;

  for (long row = rowstart,rset=0; row<rowend; row++,rset++) {
    for (long col= colstart,cset=0; col<colend; col++,cset++) {
       H[rset][cset] = genH0(row, col,n);
    }
  } 
  double *tp = new double[div];
  double *btm = new double[div];
  double *rgt = new double[div];
  double *lft = new double[div];
  double *tp1 = new double[div];
  double *btm1 = new double[div];
  double *rgt1 = new double[div];
  double *lft1 = new double[div];
  
  int top,bottom,left,right;
  left =cDiv?rank-1:-1;
  right = (cDiv == (p-1))?-1:rank+1;
  top = rank-p;
  bottom = rank+p;
  MPI_Status status[4];
  MPI_Request requests[8];
  long count = 0;
  double start = MPI_Wtime();
  for (long it = 0; it<k; it++) 
  {
     for(long ind =0,ite = 0;ind < div;ind++)
       {
   lft[ite] = H[ind][0];
   rgt[ite] = H[ind][div-1];
   tp[ite]  = H[0][ind];
   btm[ite] = H[div-1][ind];
   lft1[ite] = H[ind][0];
   rgt1[ite] = H[ind][div-1];
   tp1[ite]  = H[0][ind];
   btm1[ite] = H[div-1][ind];
   ite++;
       }
     count = 0;  
     if(top>=0){
       MPI_Isend(tp1,div,MPI_DOUBLE,top,0,MPI_COMM_WORLD,&requests[count]);
       count++;
     }
     if(right != -1){
       MPI_Isend(rgt1,div,MPI_DOUBLE,right,1,MPI_COMM_WORLD,&requests[count]);
       count++;
     }
     if(bottom < np){
       MPI_Isend(btm1,div,MPI_DOUBLE,bottom,2,MPI_COMM_WORLD,&requests[count]);
       count++;
     }
     if(left != -1){
       MPI_Isend(lft1,div,MPI_DOUBLE,left,3,MPI_COMM_WORLD,&requests[count]);
       count++;
     }
     for(long i=1;(i+1)<div;i++)
       {
   for(long j=1;(j+1)<div;j++)
     {
       G[i][j] = (H[i][j] + H[i-1][j] + H[i+1][j] + H[i][j-1] + H[i][j+1])/5;
     }
       }
  
     if(top >= 0){
       MPI_Recv(tp,div,MPI_DOUBLE,top,2,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
      
     }
     if(right != -1){
       MPI_Recv(rgt,div,MPI_DOUBLE,right,3,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
      
     }
     if(bottom < np){
       MPI_Recv(btm,div,MPI_DOUBLE,bottom,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
       
     }
     if(left != -1){
       MPI_Recv(lft,div,MPI_DOUBLE,left,1,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
       
     }
     G[0][0] = (H[0][0] + tp[0] + lft[0] + H[0][1] + H[1][0])/5;
     G[0][div-1] = (H[0][div-1] + tp[div-1] + rgt[0]+H[0][div-2]+H[1][div-1])/5;
     G[div-1][0] = (H[div-1][0] + btm[0] + lft[div-1]+H[div-1][1]+H[div-2][0])/5;
     G[div-1][div-1] = (H[div-1][div-1] + btm[div-1] +
          rgt[div-1]+H[div-1][div-2]+H[div-2][div-1])/5;
     for(long i=1,j=1;i<div-1;i++,j++)
   {
      G[0][i] = (H[0][i]+H[1][i]+tp[i]+H[0][i-1]+H[0][i+1])/5;
      G[div-1][i] = (H[div-1][i]+H[div-2][i]+btm[i]+H[div-1][i-1]+H[div-1][i+1])/5;
      G[j][0] = (H[j][0]+lft[j]+H[j][1]+H[j-1][0]+H[j+1][0])/5;
      G[j][div-1] = (H[j][div-1]+H[j-1][div-1]+H[j+1][div]+rgt[j]+H[j][div-2])/5;
   }
      H = G;

      check2DHeat(H,n,rank,vv,it);
      MPI_Waitall(count,requests,status);
             
   }
  if(rank == 0)
    {
       double end = MPI_Wtime();
       cerr<<end-start<<endl; 
    }
 for(long i=0;i<div;i++)
   delete[] H[i];
  delete[] H;
  delete[] tp;
  delete[] btm;
  delete[] rgt;
  delete[] lft;
  MPI_Finalize();

  return 0;
}




