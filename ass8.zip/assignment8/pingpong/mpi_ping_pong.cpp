#include <mpi.h>
#include <iostream>
using namespace std;
int main (int argc, char* argv[]) {

  if (argc < 2) {
    std::cerr<<"usage: mpirun "<<argv[0]<<" <value>"<<std::endl;
    return -1;
  }
  MPI_Init(&argc,&argv);
  
		int size,rank;
		MPI_Comm_size(MPI_COMM_WORLD, &size);
 		MPI_Comm_rank(MPI_COMM_WORLD, &rank);

		if(size!=2)
		{
			std::cerr<<"Please enter 2 processors";
			return -1;
		}
		
			int processor1_rev;
			int k;
	
	int val;
	int sendvariable=atoi(argv[1]);
	int recv;
	int partner_rank = (rank + 1) % 2;
for(int count=0;count<5;count++) {
    if (rank == 0) {
cout<<" Processor "<<rank<<" sent "<<sendvariable<<" from O to 1"; 
        MPI_Send(&sendvariable, 1, MPI_INT, 1, 0,
                 MPI_COMM_WORLD);
			MPI_Recv(&recv, 1, MPI_INT, 1, 0,
                 MPI_COMM_WORLD, MPI_STATUS_IGNORE);
				   printf("%d received variable %d from %d\n",
               rank, recv, 1);
				 
		
    } else {
		if(count==1)
		{
        MPI_Recv(&val, 1, MPI_INT, 0, 0,
                 MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		    printf("%d received variable %d from %d\n",   rank, val, 0);

	val+=2;			 
		}
		if(count==3)
		{
			        MPI_Send(&val, 1, MPI_INT, 0, 0,
                 MPI_COMM_WORLD);
 printf("%d sent variable  %d from %d to %d\n",
               rank, val, 1,0);
		}
    }
}	
		MPI_Finalize();

  return 0;
}

